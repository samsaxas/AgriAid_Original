"""Translation services and complete AgriAid interface strings."""
import json
import logging
import os
from functools import lru_cache

from deep_translator import GoogleTranslator
from langdetect import DetectorFactory, LangDetectException, detect

DetectorFactory.seed = 0
logger = logging.getLogger(__name__)
TRANSLATIONS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "translations")
LANGS = {
    "english": ("en", "en"), "hindi": ("hi", "hi"), "telugu": ("te", "te"),
    "tamil": ("ta", "ta"), "kannada": ("kn", "kn"), "punjabi": ("pa", "pa"),
    "bengali": ("bn", "bn"), "gu": ("gu", "gu"),
}
LANG_NAMES = {"english":"English", "hindi":"Hindi", "telugu":"Telugu", "tamil":"Tamil", "kannada":"Kannada", "punjabi":"Punjabi", "bengali":"Bengali", "gu":"Gujarati"}
LABEL_KEYS = ["diagnosis", "remedies", "prevention", "confidence", "contagion"]
LABELS_EN = ["Diagnosis", "Remedies", "Prevention", "Confidence", "Contagion risk"]

# Every visible, fixed interface phrase has a key. HTML elements use these keys via data-i18n.
UI_EN = {
 "nav_diagnose":"Diagnose", "nav_how":"How it works", "nav_features":"Features", "nav_crops":"Crops",
 "eyebrow":"AI-powered crop protection", "hero_title":"Know what's wrong with your crop — in your own language.",
 "hero_lead":"Describe the problem, upload a photo, or just speak. AgriAid gives you likely causes, treatment steps and prevention tips in seconds, and can read them aloud.",
 "start_diagnosis":"Start diagnosis", "how_button":"How it works", "languages_count":"languages", "input_modes":"input modes", "audio_answers":"audio answers",
 "diagnosis_title":"Multilingual crop disease diagnosis", "supported_crops":"Supported crops: tomatoes, potatoes, wheat, rice, and common vegetables",
 "tab_text":"✍️ Text", "tab_photo":"📷 Photo", "tab_voice":"🎙️ Voice", "describe_issue":"Describe the issue in your language",
 "text_placeholder":"e.g., My tomato leaves have yellow spots...", "upload_image":"Upload crop image", "upload_hint":"Drag & drop or click · JPG, PNG, WEBP · max 8 MB",
 "photo_tip":"Tip: take a close, well-lit photo of the affected leaf.", "click_to_record":"Click to record", "recording":"Recording… click to stop",
 "or_upload_audio":"Or upload an audio file", "audio_tip":"Upload a voice recording describing the crop problem.", "diagnose":"Diagnose",
 "empty_result":"Your diagnosis will appear here.", "analyzing":"Analyzing...", "remedies":"Remedies", "prevention":"Prevention",
 "listen":"🔊 Listen", "copy":"📋 Copy", "print":"🖨️ Print", "disclaimer":"AI guidance only. For serious or widespread outbreaks, consult a local agronomist.",
 "how_title":"How it works", "step1_title":"Tell us the problem", "step1_text":"Type symptoms in any supported language, upload a photo of the leaf, or record a short voice note.",
 "step2_title":"AI analyses it", "step2_text":"Google Gemini identifies the most likely disease, pest or deficiency and how confident it is.",
 "step3_title":"Get a plan", "step3_text":"Receive treatment steps and prevention tips in your language — and listen to them if reading is hard.",
 "features_title":"Built for farmers", "feature_languages":"8 languages", "feature_languages_text":"English, Hindi, Telugu, Tamil, Kannada, Punjabi, Bengali and Gujarati.",
 "feature_speak":"Speak or type", "feature_speak_text":"Voice input transcribes your description, even in regional languages.",
 "feature_photo":"Photo diagnosis", "feature_photo_text":"Upload an image of the affected plant for a visual assessment.",
 "feature_audio":"Audio answers", "feature_audio_text":"Hear the diagnosis and remedies read out in your language.",
 "feature_phone":"Works on any phone", "feature_phone_text":"Responsive design that works on low-end phones and desktops alike.",
 "feature_private":"Private by design", "feature_private_text":"No account needed. Photos and audio are not stored by AgriAid.",
 "crops_title":"Crops we handle well", "crop_leafy":"Leafy vegetables", "crops_note":"Diagnoses are AI suggestions and accuracy depends on input quality. Always confirm severe cases with a local agronomist or agriculture office.",
 "footer_tagline":"AI-powered crop disease diagnosis for farmers.", "footer_powered":"Powered by Google Gemini",
 "error_network":"Cannot reach the server. Check your connection and try again.", "error_image":"Please choose a JPG, PNG or WEBP image.", "error_image_size":"That image is larger than 8 MB.",
 "error_audio_size":"That audio file is larger than 12 MB.", "error_text":"Please describe the crop issue", "error_photo":"Please choose a photo first.", "error_voice":"Please record or upload audio first.",
 "error_recording":"Recording is not supported in this browser. Please upload an audio file instead.", "error_mic":"Microphone access was blocked. Allow it in your browser or upload an audio file.",
 "error_audio_process":"Could not process the recording. Please try again or upload a file.", "error_audio_unavailable":"Audio is unavailable right now: ",
 "error_translation":"Translation was unavailable, so this answer is shown in English.", "copied":"✅ Copied", "recorded":"Recorded voice note", "diagnosis_label":"Diagnosis", "confidence":"Confidence", "contagion":"Contagion risk",
 "art_early":"Early blight", "art_early_tip":"Remove infected leaves · Rotate crops", "art_rust":"Leaf rust", "art_rust_tip":"Apply fungicide · Use resistant varieties",
 "language_label":"Language", "print":"🖨️ Print", "disclaimer":"AI guidance only. For serious or widespread outbreaks, consult a local agronomist.",
 "crop_tomato":"🍅 Tomato", "crop_potato":"🥔 Potato", "crop_wheat":"🌾 Wheat", "crop_rice":"🍚 Rice", "crop_chilli":"🌶️ Chilli", "crop_brinjal":"🍆 Brinjal", "crop_maize":"🌽 Maize"
}

class TranslationError(RuntimeError):
    pass

@lru_cache(maxsize=1)
def load_translations():
    out = {}
    for fname in sorted(os.listdir(TRANSLATIONS_DIR)):
        if fname.endswith('.json'):
            with open(os.path.join(TRANSLATIONS_DIR, fname), encoding='utf-8') as f:
                out[fname[:-5]] = json.load(f)
    return out

def language_list():
    return [{"code": c, "name": LANG_NAMES[c]} for c in LANGS]

def tr_code(lang):
    if lang not in LANGS: raise ValueError(f"Unsupported language: {lang}")
    return LANGS[lang][0]

def tts_code(lang): return LANGS.get(lang, ("en", "en"))[1]

def translate_to_english(text):
    text = (text or '').strip()
    if not text: return text
    try:
        if detect(text) == 'en': return text
    except LangDetectException: pass
    try: return GoogleTranslator(source='auto', target='en').translate(text[:4500]) or text
    except Exception as e: raise TranslationError(f"Could not translate input to English: {e}") from e

def _gemini_translate(items, lang):
    from app.gemini import _generate
    import json as _json
    prompt = (f"Translate each string in this JSON array from English to {LANG_NAMES[lang]} ({tr_code(lang)}). "
              "Return ONLY a valid JSON array with exactly the same number and order of strings. "
              "Do not omit, explain, or combine any item. Preserve numbers, names and units.\n" + _json.dumps(items, ensure_ascii=False))
    raw = _generate([prompt], temperature=0.0)
    try:
        parsed = _json.loads(raw[raw.find('['):raw.rfind(']')+1])
        if isinstance(parsed, list) and len(parsed) == len(items) and all(isinstance(x, str) and x.strip() for x in parsed): return parsed
    except Exception: pass
    raise TranslationError('Gemini returned an invalid translation response.')

def translate_batch(items, lang):
    """Translate in small batches; use Gemini if Google Translate is unreachable."""
    items = list(items)
    code = tr_code(lang)
    if code == 'en' or not items: return items, True
    translated = []
    for offset in range(0, len(items), 12):
        chunk = items[offset:offset + 12]
        result = None
        try:
            candidate = GoogleTranslator(source='en', target=code).translate_batch(chunk)
            if len(candidate) == len(chunk) and all(candidate): result = candidate
        except Exception as e:
            logger.warning('Google translation failed for %s: %s', lang, e)
        if result is None:
            try: result = _gemini_translate(chunk, lang)
            except Exception as e:
                logger.error('Gemini translation failed for %s: %s', lang, e)
                return items, False
        translated.extend(result)
    return translated, True

@lru_cache(maxsize=32)
def translated_labels(lang):
    res, _ = translate_batch(LABELS_EN, lang)
    return dict(zip(LABEL_KEYS, res))

_UI_TRANSLATION_CACHE = {}

def translated_ui(lang):
    """Return a complete UI dictionary. Cache only successful translations.

    A failed provider must never be reported as a successful language change.
    """
    if lang == "english":
        return dict(UI_EN)
    if lang in _UI_TRANSLATION_CACHE:
        return dict(_UI_TRANSLATION_CACHE[lang])

    keys = list(UI_EN)
    values, ok = translate_batch([UI_EN[k] for k in keys], lang)
    if not ok or len(values) != len(keys):
        raise TranslationError(
            f"Could not translate the complete interface into {LANG_NAMES[lang]}. "
            "Check Google Translate connectivity or your Gemini API key, then retry."
        )

    translated = dict(zip(keys, values))
    _UI_TRANSLATION_CACHE[lang] = translated
    return dict(translated)

@lru_cache(maxsize=32)
def translated_labels(lang):
    if lang == "english":
        return dict(zip(LABEL_KEYS, LABELS_EN))
    ui = translated_ui(lang)
    return {
        "diagnosis": ui.get("diagnosis_label", "Diagnosis"),
        "remedies": ui.get("remedies", "Remedies"),
        "prevention": ui.get("prevention", "Prevention"),
        "confidence": ui.get("confidence", "Confidence"),
        "contagion": ui.get("contagion", "Contagion risk"),
    }

def language_payload(lang):
    """Return every interface phrase in the selected language.

    The project JSON translations override machine translations where a
    reviewed/manual translation exists; all remaining keys are translated
    dynamically. A provider failure raises instead of silently showing English.
    """
    if lang not in LANGS:
        raise ValueError(f"Unsupported language: {lang}")

    strings = translated_ui(lang)
    all_files = load_translations()
    existing = all_files.get(lang, {})
    english_strings = all_files.get("english", {}).get("strings", {})
    # Keep reviewed translations, but do not let English placeholders in the
    # older JSON files overwrite newly translated interface strings.
    for key, value in existing.get("strings", {}).items():
        if value and value != english_strings.get(key):
            strings[key] = value
    strings.update(translated_labels(lang))
    return {
        "language_name": LANG_NAMES[lang],
        "strings": strings,
        "translation_complete": True,
    }
